package com.example.practice.domain.member.entity;

public enum MemberRole {
    USER, ADMIN;
}
