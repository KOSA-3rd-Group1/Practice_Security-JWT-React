//package com.example.practice.domain.auth.exception;
//
//import lombok.Getter;
//
//@Getter
//public class LoginException extends RuntimeException{
//
//    private final LoginErrorCode errorCode;
//
//    public LoginException(LoginErrorCode errorCode) {
//        super(errorCode.getMessage());
//        this.errorCode = errorCode;
//    }
//}
