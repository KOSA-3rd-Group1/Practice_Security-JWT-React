//package com.example.practice.web.auth.controller;
//
//import com.example.practice.domain.auth.service.LoginService;
//import com.example.practice.web.auth.dto.WebLoginRequestDTO;
//import jakarta.validation.Valid;
//import lombok.RequiredArgsConstructor;
//import lombok.extern.slf4j.Slf4j;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.authentication.AuthenticationManager;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.core.Authentication;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@Slf4j
//@RestController
//@RequestMapping("/api/auth")
//@RequiredArgsConstructor
//public class AuthController {
//
//    private final LoginService loginService;
//    private AuthenticationManager authenticationManager;
////
////    @PostMapping("/login")
////    public ResponseEntity<String> login(@RequestBody @Valid WebLoginRequestDTO request) {
////        log.info("이거 찍히나??????????????");
////        try {
////            Authentication authentication = authenticationManager.authenticate(
////                    new UsernamePasswordAuthenticationToken(request.getLoginId(), request.getPassword())
////            );
////
////            //로그인 성공 시 JWT 토큰 생성
////        } catch (Exception e) {
////            e.printStackTrace();
////        }
////
////
////        return ResponseEntity.ok(loginService.login(request));
////    }
//}
