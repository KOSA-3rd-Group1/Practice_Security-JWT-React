//package com.example.practice.web.auth.dto;
//
//import jakarta.validation.constraints.NotBlank;
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//
//@AllArgsConstructor
//@NoArgsConstructor
//@Getter
//@Builder
//public class WebLoginRequestDTO {
//    @NotBlank
//    private String loginId;
//
//    @NotBlank
//    private String password;
//}
