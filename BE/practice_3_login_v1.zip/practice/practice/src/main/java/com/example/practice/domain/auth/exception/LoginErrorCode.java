//package com.example.practice.domain.auth.exception;
//
//import lombok.Getter;
//
//@Getter
//public enum LoginErrorCode {
//    ID_NOT_FOUND("ID not found"),
//    PASSWORD_INVALID("Password invalid");
//
//    private final String message;
//
//    LoginErrorCode(String message) {
//        this.message = message;
//    }
//}
