//package com.example.practice.domain.auth.service;
//
//import com.example.practice.domain.auth.exception.LoginErrorCode;
//import com.example.practice.domain.auth.exception.LoginException;
//import com.example.practice.domain.member.entity.Member;
//import com.example.practice.domain.member.repository.MemberRepository;
//import com.example.practice.domain.security.util.JWTUtil;
//import com.example.practice.web.auth.dto.WebLoginRequestDTO;
//import jakarta.transaction.Transactional;
//import lombok.RequiredArgsConstructor;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Service;
//
//
//@Service
//@RequiredArgsConstructor
//public class LoginService {
//
//    private final MemberRepository memberRepository;
//    private final PasswordEncoder passwordEncoder;
//
//    @Transactional
//    public String login(WebLoginRequestDTO request) {
//        //ID 체크
//        Member member = memberRepository.getWithRoles(request.getLoginId())
//                .orElseThrow(() -> new LoginException(LoginErrorCode.ID_NOT_FOUND));
//
//        //PW 체크
//        if (!passwordEncoder.matches(request.getPassword(), member.getPw())) {
//            throw new LoginException(LoginErrorCode.PASSWORD_INVALID);
//        }
//
//        //로그인 성공 시, JWT 토큰 생성
////        String token = JWTUtil.generateToken(member.getEmail());
//        return null;
//    }
//
//}
