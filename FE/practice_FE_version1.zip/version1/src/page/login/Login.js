import { LoginFormComponent } from "components/login/LoginFormComponent"

export const Login = () => {

	return (
		<div>
			<LoginFormComponent />
		</div>
	)
	
}