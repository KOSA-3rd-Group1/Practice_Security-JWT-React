
// components
import { InquiriesComponent } from "components/inquiry/InquiriesComponent";
import useAuthentication from "hook/auth/useAuthentication";


// 문의글 전체 데이터 가져오기
export const Inquiry = () => {
	useAuthentication();

	return (
		<div>
			<p>로그인이 필요한 페이지</p>
			<>
				<hr />
				<InquiriesComponent />
			</>
		</div>
	)
	
}