import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { Main } from 'page/main/Main'
import { Login } from 'page/login/Login';
import { Inquiry } from 'page/Inquiry/Inquiry';

function App() {
	return (
	<div className="App">
		<BrowserRouter>
			<Routes>
				<Route path='/' element={<Main />} />
				<Route path='/login' element={<Login />} />
				<Route path='/inquiries' element={<Inquiry />} />
			</Routes>
		</BrowserRouter>
    </div>
	);
}

export default App;
